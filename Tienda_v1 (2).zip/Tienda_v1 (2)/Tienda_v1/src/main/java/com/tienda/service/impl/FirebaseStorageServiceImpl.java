/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.service.impl;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Lizeth
 */
public class FirebaseStorageServiceImpl {

    String cargaImagen(MultipartFile imagenFile, String usuarios, Long idUsuario) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
